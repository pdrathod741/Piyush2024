!function() {
    function e() {
        L.forEach(function(e) {
            window.clearTimeout(e)
        })
    }
    function n() {
        l() ? (function() {
            function e() {
                n.every(function(e) {
                    return e.complete
                }) ? (F = !0,
                L.push(setTimeout(function() {
                    I.querySelector(".hpc-tablet__image").src = p + _ + "/png_illustrations/Website_pad.png",
                    W.querySelector(".hpc-phone__image").src = p + _ + "/png_illustrations/Instagram_mob.png",
                    c(W.querySelector(".hpc-phone__cover"), "calypso-no-bg-loaded", !1),
                    c(I.querySelector(".hpc-tablet__cover"), "calypso-no-bg-loaded", !1),
                    c(M, "calypso-no-bg-loaded", !1),
                    c(v.querySelector(".hpc-pics__bg"), "hpc-animate--animated", !0),
                    c(v.querySelector(".hpc-pics__glasses"), "hpc-animate--animated", !0),
                    c(v.querySelector(".hpc-pics__phone"), "hpc-animate--animated", !0),
                    c(v.querySelector(".hpc-pics__tablet"), "hpc-animate--animated", !0)
                }, 100)),
                setTimeout(function() {
                    t(),
                    z.forEach(function(e) {
                        var n = [];
                        e.forEach(function(e) {
                            var i = []
                              , t = [];
                            e.forEach(function(e) {
                                var n = new Image;
                                n.src = e.src,
                                n.classList = "hpc-slider__layer " + e.class,
                                t.push(n)
                            }),
                            i.push(t),
                            n.push(i)
                        }),
                        G.push(n)
                    })
                }, 1e3)) : setTimeout(e, g)
            }
            var n = [];
            [{
                el: M,
                media: p + "glasses.png"
            }, {
                el: W,
                media: p + "phone.png"
            }, {
                el: I,
                media: p + "tablet.png"
            }, {
                el: null,
                media: p + "phone-slide1_.jpg"
            }, {
                el: null,
                media: p + "tablet-slide1.jpg"
            }].forEach(function(e) {
                var i = new Image;
                i.src = e.media,
                n.push(i)
            }),
            h.forEach(function(e) {
                var i = new Image
                  , t = new Image;
                i.src = e.phone,
                t.src = e.tablet,
                n.push(i),
                n.push(t)
            });
            document.querySelectorAll(".hpc-head.hpc-animate, .hpc-text .hpc-animate, .hpc-chevron.hpc-animate").forEach(function(e) {
                c(e, "hpc-animate--animated", !0)
            }),
            L.push(setTimeout(function() {
                !function() {
                    function e() {
                        L.push(setTimeout(function() {
                            A.innerText = h[r(i)].wording,
                            c(E, "hpc-underlined--" + h[i].color, !1),
                            c(E, "hpc-underlined--" + h[r(i)].color, !0),
                            h[r(i)].showOn ? h[r(i)].showA ? O.innerText = h[r(i)].showOn + " " + h[r(i)].showA : O.innerText = h[r(i)].showOn + " " : O.innerText = "",
                            F ? (O.innerText = "",
                            A.innerText = h[0].wording,
                            c(E, "hpc-underlined--" + h[r(i)].color, !1),
                            c(E, "hpc-underlined--" + h[0].color, !0)) : ++i < h.length ? e() : (i = 0,
                            e())
                        }, n))
                    }
                    if (d())
                        return;
                    var n = l() ? m : 2 * m
                      , i = 0;
                    e()
                }()
            }, 1500)),
            setTimeout(function() {
                setTimeout(function() {
                    e()
                }, 6 * m)
            }, 1500)
        }(),
        function() {
            function e() {
                function e(e) {
                    H.forEach(function(n, t) {
                        var o = $(n.selector)
                          , r = o.offset().top
                          , s = r + o.outerHeight()
                          , l = $(window).scrollTop()
                          , d = l + i;
                        if (d >= r && d <= s && "down" == e)
                            switch (P = t,
                            t) {
                            case 1:
                                a(0, 0, ".hpc-slider--0"),
                                $(C).hide();
                                break;
                            case 2:
                                a(1, 0, ".hpc-slider--1");
                                break;
                            case 3:
                                setTimeout(function() {
                                    $(".hpc-slider--2 .hpc-slider__slide").addClass("hpc-slider__slide--animated")
                                }, 100),
                                c(B, "calypso-no-bg-loaded", !1)
                            }
                        else if ("up" == e && l < s && l > r)
                            switch (P = t,
                            t) {
                            case 0:
                                $(C).show();
                                break;
                            case 1:
                                a(0, 0, ".hpc-slider--0");
                                break;
                            case 2:
                                a(1, 0, ".hpc-slider--1");
                                break;
                            case 3:
                                setTimeout(function() {
                                    $(".hpc-slider--2 .hpc-slider__slide").addClass("hpc-slider__slide--animated")
                                }, 100),
                                c(B, "calypso-no-bg-loaded", !1)
                            }
                        else
                            "loaded" == e && d >= r && d <= s && (P = t,
                            t > 0 && ($(".hpc-slider--0 .hpc-slider__slide").addClass("hpc-slider__slide--animated"),
                            $(".hpc-slider--1 .hpc-slider__slide").addClass("hpc-slider__slide--animated"),
                            $(".hpc-slider--2 .hpc-slider__slide").addClass("hpc-slider__slide--animated"),
                            $(C).hide()))
                    })
                }
                var o = $(window).scrollTop();
                n > o ? e("up") : n < o ? e("down") : t || (e("loaded"),
                t = !0),
                n = o
            }
            if (d())
                return $(C).hide(),
                void $(".hpc-slider__slide").addClass("hpc-slider__slide--animated");
            var n = $(window).scrollTop()
              , i = $(window).height()
              , t = !1;
            $(document).ready(function() {
                setTimeout(function() {
                    e()
                }, 100),
                $(window).on("scroll", e)
            })
        }()) : i(),
        void 0 !== document.getElementsByClassName("hpc-head") && void 0 !== document.getElementsByClassName("hpc-head")[0] && document.getElementsByClassName("hpc-head")[0].classList.add("hpc-head--EW19")
    }
    function i() {
        !function() {
            var e = document.getElementById("hpc_mobile_single_slide")
              , n = document.getElementById("hpc_tablet_single_slide");
            s() < 768 ? (e.src = p + _ + "/Mobile/png/Mobile_Website_illustration.png",
            n.src = "") : s() < 992 ? (e.src = "",
            n.src = p + _ + "/Mobile/png/Mobile_Website_illustration.png") : (e.src = "",
            n.src = "")
        }(),
        document.querySelectorAll(".hpc-text .hpc-animate, .hpc-mobile-pics.hpc-animate").forEach(function(e) {
            c(e, "hpc-animate--animated", !0)
        });
        var e = !0;
        d() && (e = !1),
        $("#mobile_slider_1, #mobile_slider_2").slick({
            lazyLoad: "progressive",
            slidesToShow: 1,
            slidesToScroll: 1,
            autoplay: e,
            dots: !0,
            arrows: !1
        })
    }
    function t(e) {
        function n(e) {
            L.push(setTimeout(function() {
                o(e),
                ++e < h.length && n(e)
            }, u))
        }
        if (!d() && !H[0].isStarted) {
            L = [];
            o(0),
            n(1),
            document.querySelector(".hpc-text").style.opacity = "1"
        }
    }
    function o(e) {
        var n = e
          , i = h[n]
          , t = r(n)
          , o = h[t];
        !function(e, n, i, t, o, r, s) {
            var l = o.length
              , a = t.length - 1;
            c(x, "hpc-caret--show", !0),
            c(x, "hpc-caret--blink", !1),
            function(e, n, i, t) {
                function o() {
                    L.push(setTimeout(function() {
                        e.innerText = i[r].line,
                        O.innerText = i[r].pref,
                        ++r < i.length && o()
                    }, f))
                }
                var r = 0;
                o()
            }(A, 0, o, r.eraseOn),
            L.push(setTimeout(function() {
                c(E, "hpc-underlined--no-line", !0),
                c(E, "hpc-underlined--" + e, !1),
                c(E, "hpc-underlined--" + n, !0),
                L.push(setTimeout(function() {
                    c(E, "hpc-underlined--no-line", !1),
                    function(e, n, i, t, o, r) {
                        function s() {
                            L.push(setTimeout(function() {
                                e.innerText = n.slice(0, t + l),
                                ++l <= i && s()
                            }, f - 50))
                        }
                        var l = 1;
                        o ? (c(E, "hpc-underlined--no-line", !0),
                        r ? (O.innerText = "",
                        L.push(setTimeout(function() {
                            O.innerText = o,
                            L.push(setTimeout(function() {
                                O.innerText = o + " ",
                                L.push(setTimeout(function() {
                                    O.innerText = o + " " + r,
                                    L.push(setTimeout(function() {
                                        O.innerText = o + " " + r + " ",
                                        L.push(setTimeout(function() {
                                            c(E, "hpc-underlined--no-line", !1),
                                            e.innerText = n.slice(0, 1),
                                            s()
                                        }, f - 50))
                                    }, f - 50))
                                }, f - 50))
                            }, f - 50))
                        }, f - 50))) : (O.innerText = "",
                        L.push(setTimeout(function() {
                            O.innerText = o,
                            L.push(setTimeout(function() {
                                O.innerText = o + " ",
                                L.push(setTimeout(function() {
                                    c(E, "hpc-underlined--no-line", !1),
                                    e.innerText = n.slice(0, 1),
                                    s()
                                }, f - 50))
                            }, f - 50))
                        }, f - 50)))) : (e.innerText = n.slice(0, 1),
                        s())
                    }(A, t, a, 1, s.printOn, s.printA),
                    L.push(setTimeout(function() {
                        c(x, "hpc-caret--blink", !0)
                    }, f * a))
                }, w))
            }, f * l))
        }(i.color, o.color, i.wording, o.wording, i.frames, i, o),
        function(e, n) {
            c(k, "hpc-animate", !1),
            c(k, "hpc-animate--animated", !1),
            c(k, "hpc-animate--delay-4", !1),
            L.push(setTimeout(function() {
                c(k, "hpc-pics__bg--" + e, !1),
                c(k, "hpc-pics__bg--" + n, !0)
            }, 400))
        }(i.color, o.color),
        function(e) {
            var n = W.querySelector(".hpc-phone__slide--current")
              , i = W.querySelector(".hpc-phone__slide--next");
            i.querySelector(".hpc-phone__image").src = e,
            L.push(setTimeout(function() {
                c(W, "hpc-phone--switch", !0),
                L.push(setTimeout(function() {
                    c(W, "hpc-phone--switch", !1),
                    c(n, "hpc-phone__slide--current", !1),
                    c(n, "hpc-phone__slide--next", !0),
                    c(i, "hpc-phone__slide--next", !1),
                    c(i, "hpc-phone__slide--current", !0)
                }, b))
            }, T))
        }(o.phone),
        function(e) {
            var n = I.querySelector(".hpc-tablet__slide--current")
              , i = I.querySelector(".hpc-tablet__slide--next");
            i.querySelector(".hpc-tablet__image").src = e,
            L.push(setTimeout(function() {
                c(I, "hpc-tablet--switch", !0),
                L.push(setTimeout(function() {
                    c(I, "hpc-tablet--switch", !1),
                    c(n, "hpc-tablet__slide--current", !1),
                    c(n, "hpc-tablet__slide--next", !0),
                    c(i, "hpc-tablet__slide--next", !1),
                    c(i, "hpc-tablet__slide--current", !0)
                }, S))
            }, y))
        }(o.tablet)
    }
    function r(e) {
        return h.length - 1 === e ? 0 : e + 1
    }
    function s() {
        return window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth
    }
    function l() {
        return s() >= 992
    }
    function c(e, n, i) {
        i ? e.classList.contains(n) || e.classList.add(n) : e.classList.remove(n)
    }
    function a(e, n, i) {
        function t(n) {
            s.removeClass("hpc-slider__slide--" + (n - 1)),
            s.addClass("hpc-slider__slide--" + n),
            s.addClass("hpc-slider__slide--animated"),
            n + 1 < z[e].length && setTimeout(function() {
                s.removeClass("hpc-slider__slide--animated"),
                setTimeout(function() {
                    !function(n) {
                        if (G[e] && n < G[e].length) {
                            var i = G[e][n + 1];
                            s.html(""),
                            i.forEach(function(e) {
                                s.append(e)
                            })
                        }
                    }(n)
                }, 500)
            }, 2e3)
        }
        function o() {
            setTimeout(function() {
                t(r),
                G[e] && r < G[e].length && o(),
                r++
            }, 2700)
        }
        z[e][n];
        var r = 1
          , s = $(i).find(".hpc-slider__slide");
        if (N[e])
            return !1;
        N[e] = !0,
        t(0),
        o()
    }
    var d = function() {
        return 1 * window.navigator.userAgent.indexOf("HeadlessChrome") > -1
    }
     
    if ("function" == typeof get_hpc_mainSlides)
        var h = get_hpc_mainSlides()
          , _ = get_lang_prefix();
    if (void 0 == h) {
        _ = "en";
        "undefined" == typeof mainSlides_wording_0 && (mainSlides_wording_0 = "Online for Free"),
        "undefined" == typeof mainSlides_loaderWording_0 && (mainSlides_loaderWording_0 = "Online for Free"),
        "undefined" == typeof mainSlides_frames_0 && (mainSlides_frames_0 = [{
            pref: "",
            line: "Online for Free"
        }, {
            pref: "",
            line: "Online for Fre"
        }, {
            pref: "",
            line: "Online for Fr"
        }, {
            pref: "",
            line: "Online for"
        }, {
            pref: "",
            line: "Online"
        }, {
            pref: "",
            line: ""
        }]);
        h = [{
            wording: mainSlides_wording_0,
            loaderWording: mainSlides_loaderWording_0,
            frames: mainSlides_frames_0,
            showOn: !1,
            showA: !1,
            printA: !1,
            eraseA: !1,
            printOn: !1,
            eraseOn: !1,
            color: "yellow",
            phone: p + "phone-slide1_.jpg",
            tablet: p + "tablet-slide1.jpg"
        }, {
            wording: "Website",
            loaderWording: "on a Website",
            frames: [{
                pref: "on a ",
                line: "Website"
            }, {
                pref: "on a ",
                line: "Websit"
            }, {
                pref: "on a ",
                line: "Websi"
            }, {
                pref: "on a ",
                line: ""
            }, {
                pref: "on ",
                line: ""
            }],
            showOn: "on",
            showA: "a",
            printA: "a",
            eraseA: !1,
            printOn: "on",
            eraseOn: !1,
            color: "green",
            phone: p + "phone-slide2.jpg",
            tablet: p + "tablet-slide1.jpg"
        }, {
            wording: "Instagram",
            loaderWording: "on Instagram",
            frames: [{
                pref: "on ",
                line: "Instagram"
            }, {
                pref: "on ",
                line: "Instagra"
            }, {
                pref: "on ",
                line: "Instagr"
            }, {
                pref: "on ",
                line: ""
            }],
            showOn: "on",
            showA: !1,
            printA: !1,
            eraseA: "a",
            printOn: !1,
            eraseOn: !1,
            color: "magenta",
            phone: p + "phone-slide1.jpg",
            tablet: p + "tablet-slide3.jpg"
        }, {
            wording: "Facebook",
            loaderWording: "on Facebook",
            frames: [{
                pref: "on ",
                line: "Facebook"
            }, {
                pref: "on ",
                line: "Faceboo"
            }, {
                pref: "on ",
                line: "Facebo"
            }, {
                pref: "on ",
                line: ""
            }],
            showOn: "on",
            printA: !1,
            showA: !1,
            eraseA: !1,
            printOn: !1,
            eraseOn: !1,
            color: "indigo",
            phone: p + "phone-slide4.jpg",
            tablet: p + "tablet-slide4.jpg"
        }, {
            wording: "TikTok",
            loaderWording: "on TikTok",
            frames: [{
                pref: "on ",
                line: "TikTok"
            }, {
                pref: "on ",
                line: "TikT"
            }, {
                pref: "on ",
                line: "Tik"
            }, {
                pref: "on ",
                line: ""
            }],
            showOn: "on",
            printA: !1,
            showA: !1,
            eraseA: !1,
            printOn: !1,
            eraseOn: !1,
            color: "tiktok",
            phone: p + "phone-slide6.png",
            tablet: p + "tablet-slide6.jpg"
        }, {
            wording: "Amazon",
            loaderWording: "on Amazon",
            frames: [{
                pref: "on ",
                line: "Amazon"
            }, {
                pref: "on ",
                line: "Amazo"
            }, {
                pref: "on ",
                line: "Amaz"
            }, {
                pref: "on ",
                line: ""
            }],
            showOn: "on",
            showA: !1,
            printA: !1,
            eraseA: !1,
            printOn: !1,
            eraseOn: !1,
            color: "sandy",
            phone: p + "phone-slide5.jpg",
            tablet: p + "tablet-slide5.jpg"
        }, {
            wording: "Google",
            loaderWording: "on Google",
            frames: [{
                pref: "on ",
                line: "Google"
            }, {
                pref: "on ",
                line: "Googl"
            }, {
                pref: "on ",
                line: "Goog"
            }, {
                pref: "on ",
                line: ""
            }, {
                pref: "",
                line: ""
            }],
            showOn: "on",
            showA: !1,
            printA: !1,
            eraseA: !1,
            printOn: !1,
            eraseOn: "on",
            color: "azure",
            phone: p + "phone-slide6.jpg",
            tablet: p + "tablet-slide6.jpg"
        }]
    }
    var u = 4e3
      , m = 200
      , g = 10
      , f = 100
      , w = 300
      , T = 700
      , b = 700
      , y = 700
      , S = 700
      , v = document.getElementById("hpc_pics")
      , x = document.getElementById("hpc_caret")
      , E = document.getElementById("hpc_underlined")
      , O = document.getElementById("hpc_on")
      , A = document.getElementById("hpc_sales_channel")
      , k = document.getElementById("hpc_bg")
      , W = document.getElementById("hpc_phone")
      , I = document.getElementById("hpc_tablet")
      , M = document.getElementById("hpc_glasses")
      , C = document.getElementById("hpc_chevron")
      , B = document.getElementById("hpc_map")
      , q = document.getElementsByClassName("hpc-vertical-nav__item")
      , j = document.getElementsByClassName("hpc-cart")
      , F = !1
      , z = [[[{
        src: p + _ + "/png_sliders/Slider_Website_2.png",
        class: "hpc-slider__layer--1"
    }, {
        src: p + _ + "/png_sliders/Slider_Website_1.png",
        class: "hpc-slider__layer--2"
    }], [{
        src: p + _ + "/png_sliders/Slider_Social Network_3.png",
        class: "hpc-slider__layer--1"
    }, {
        src: p + _ + "/png_sliders/Slider_Social Network_2.png",
        class: "hpc-slider__layer--2"
    }, {
        src: p + _ + "/png_sliders/Slider_Social Network_1.png",
        class: "hpc-slider__layer--3"
    }], [{
        src: p + _ + "/png_sliders/Slider_Marketplaces_3.png",
        class: "hpc-slider__layer--1"
    }, {
        src: p + _ + "/png_sliders/Slider_Marketplaces_2.png",
        class: "hpc-slider__layer--2"
    }, {
        src: p + _ + "/png_sliders/Slider_Marketplaces_1.png",
        class: "hpc-slider__layer--3"
    }], [{
        src: p + _ + "/png_sliders/Slider_POS_1.png",
        class: "hpc-slider__layer--1"
    }, {
        src: p + _ + "/png_sliders/Slider_POS_2.png",
        class: "hpc-slider__layer--2"
    }], [{
        src: p + _ + "/png_sliders/Slider_Website_2.png",
        class: "hpc-slider__layer--1"
    }, {
        src: p + _ + "/png_sliders/Slider_Website_1.png",
        class: "hpc-slider__layer--2"
    }]], [[{
        src: p + _ + "/png_sliders/Slider_Facebook_3.png",
        class: "hpc-slider__layer--1"
    }, {
        src: p + _ + "/png_sliders/Slider_Facebook_2.png",
        class: "hpc-slider__layer--2"
    }, {
        src: p + _ + "/png_sliders/Slider_Facebook_1.png",
        class: "hpc-slider__layer--3"
    }], [{
        src: p + _ + "/png_sliders/Slider_Google_3.png",
        class: "hpc-slider__layer--1"
    }, {
        src: p + _ + "/png_sliders/Slider_Google_2.png",
        class: "hpc-slider__layer--2"
    }, {
        src: p + _ + "/png_sliders/Slider_Google_1.png",
        class: "hpc-slider__layer--3"
    }]], [[{
        src: p + _ + "/png_sliders/Slider_Manage_2.png",
        class: "hpc-slider__layer--1"
    }, {
        src: p + _ + "/png_sliders/Slider_Manage_1.png",
        class: "hpc-slider__layer--2"
    }]]]
      , N = [!1, !1]
      , G = []
      , L = []
      , P = 0
      , H = [{
        selector: "#tile-1",
        isAnimated: !1,
        isStarted: !1
    }, {
        selector: "#tile-3",
        isAnimated: !1
    }, {
        selector: "#tile-4",
        isAnimated: !0
    }, {
        selector: "#tile-5",
        isAnimated: !1
    }];
    window.addEventListener("load", function() {
        n()
    }),
    window.addEventListener("resize", function() {
        l() || i()
    });
    document.querySelector(".hpc-text h1"),
    document.querySelector(".hpc-text p"),
    document.getElementById("hpc_col1"),
    document.getElementById("hpc_col2");
    $(q).mouseover(function() {
        $(q).removeClass("hpc-vertical-nav__item--active"),
        $(this).addClass("hpc-vertical-nav__item--active")
    }),
    $(j).mouseover(function() {
        $(j).removeClass("hpc-cart--active"),
        $(this).addClass("hpc-cart--active")
    }),
    $(j).mouseleave(function() {
        $(j).removeClass("hpc-cart--active")
    }),
    $(q).click(function() {
        var e = $(this).attr("data-hover");
        $.fn.fullpage.moveTo(e)
    }),
    $(C).click(function() {
        !function(e) {
            $("html, body").animate({
                scrollTop: $(e).offset().top
            }, 500)
        }("#tile-2"),
        $(C).hide()
    }),
    function() {
        if (!d()) {
            var n = $(window).height()
              , i = new ScrollMagic.Controller;
            new ScrollMagic.Scene({
                triggerElement: "#tile-1",
                offset: n / 2,
                duration: n
            }).setTween(TweenMax.fromTo(".hpc-pics--rotated", 1, {
                transform: "rotate(30deg)",
                "margin-top": "-90px"
            }, {
                transform: "rotate(0deg)",
                "margin-top": "0"
            })).on("update", function(n) {
                if (!l())
                    return !1 !== H[0].isStarted || H[0].isStartOneTime || (H[0].isStartOneTime = !0,
                    setTimeout(function() {
                        e(),
                        t()
                    }, 1500)),
                    !0;
                n.scrollPos > 10 ? H[0].isStarted || (H[0].isStarted = !0,
                e(),
                o(h.length - 1),
                $(k).attr("class", $(k).attr("class").replace(/\bhpc-pics__bg--[a-z0-9]+\b/g, "")),
                $(E).attr("class", $(E).attr("class").replace(/\bhpc-underlined--[a-z0-9]+\b/g, ""))) : n.scrollPos < 10 && !0 === H[0].isStarted && (H[0].isStarted = !1,
                e(),
                t())
            }).addTo(i),
            new ScrollMagic.Scene({
                duration: 100
            }).setTween(TweenMax.fromTo("#hpc_glasses", 1, {
                opacity: "1"
            }, {
                opacity: "0"
            })).addTo(i),
            new ScrollMagic.Scene({
                triggerElement: "#tile-1",
                offset: n / 2,
                duration: n
            }).setTween(TweenMax.fromTo(".hpc-pics__phone", 1, {
                top: "47%",
                left: "-89px"
            }, {
                top: "155%",
                left: "290px"
            })).addTo(i),
            new ScrollMagic.Scene({
                triggerElement: "#tile-1",
                offset: n / 2,
                duration: n
            }).setTween(TweenMax.fromTo(".hpc-pics__tablet", 1, {
                top: "48%",
                left: "184px"
            }, {
                top: "136%",
                left: "560px"
            })).addTo(i),
            new ScrollMagic.Scene({
                triggerElement: "#tile-1",
                offset: n / 2,
                duration: n
            }).setTween(TweenMax.fromTo(".hpc-pics__bg--first", 1, {
                right: function() {
                    return $("#hpc_bg").css("right")
                }
            }, {
                right: "-100vw"
            })).addTo(i),
            new ScrollMagic.Scene({
                triggerElement: "#tile-1",
                offset: n / 2,
                duration: n
            }).setTween(TweenMax.fromTo(".hpc-pics__bg--second", 1, {
                right: "80vw",
                transform: "rotate(30deg)"
            }, {
                right: "24vw",
                transform: "rotate(0deg)"
            })).addTo(i),
            new ScrollMagic.Scene({
                duration: 200,
                offset: 3 * n / 5
            }).setTween(TweenMax.fromTo(".hpc-text.hpc-text--first-tile", 1, {
                opacity: "0"
            }, {
                opacity: "1"
            })).addTo(i)
        }
    }()
}();
